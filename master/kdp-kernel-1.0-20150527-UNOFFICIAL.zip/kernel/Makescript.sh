#!/sbin/sh

#if [ ! -d /system/etc/init.d ]
#then
#mkdir -p /system/etc/init.d
#fi

#Build config file
SCRIPT="/tmp/KangDroidKernel.sh"

#CPU Setting
GOVERNOR=`grep "selected.1" /tmp/aroma/cpu.prop | cut -d '=' -f2`
MAXFREQ=`grep "selected.2" /tmp/aroma/cpu.prop | cut -d '=' -f2`
MINFREQ=`grep "selected.3" /tmp/aroma/cpu.prop | cut -d '=' -f2`
IDLEMAXFREQ=`grep "selected.4" /tmp/aroma/cpu.prop | cut -d '=' -f2`

#IO Settings
IO=`grep "selected.1" /tmp/aroma/io.prop | cut -d '=' -f2`
BUFFERSIZE=`grep "selected.2" /tmp/aroma/io.prop | cut -d '=' -f2`

#Double Tab 2 Wake
DTWH=`grep "item.2.1" /tmp/aroma/sleep.prop | cut -d '=' -f2`
DTWF=`grep "item.2.2" /tmp/aroma/sleep.prop | cut -d '=' -f2`

if [ $DTWH = 1 ]; then
  DTWH=1
fi
if [ $DTWF == 1 ]; then
  DTWF=2
fi

DT2W=$(( DTWH + DTWF ))

#Swipe 2 Wake

SR=`grep "item.1.1" /tmp/aroma/sleep.prop | cut -d '=' -f2`
SL=`grep "item.1.2" /tmp/aroma/sleep.prop | cut -d '=' -f2`
SU=`grep "item.1.3" /tmp/aroma/sleep.prop | cut -d '=' -f2`
SD=`grep "item.1.4" /tmp/aroma/sleep.prop | cut -d '=' -f2`

if [ $SL = 1 ]; then
  SL=2
fi
if [ $SU == 1 ]; then
  SU=4
fi
if [ $SD == 1 ]; then
  SD=8
fi  

S2W=$(( SL + SR + SU + SD ))

#S2W/DT2W Timeout
if [ ! -e /tmp/aroma/timeout.prop ]; then
  echo "selected.0=1" > /tmp/aroma/timeout.prop;
fi
TIMEOUT=`cat /tmp/aroma/timeout.prop | cut -d '=' -f2`

#S2W/DT2W Power key toggle
PWR_KEY=`grep "item.3.1" /tmp/aroma/sleep.prop | cut -d '=' -f2`

#S2W, DT2W Vib Settings
VIB_STRENGTH=`cat /tmp/aroma/gesturevib.prop | cut -d '=' -f2`

#S2S
S2S=`grep selected.0 /tmp/aroma/s2s.prop | cut -d '=' -f2`

#VIB ----
VIB=`grep "selected.1" /tmp/aroma/vib.prop | cut -d '=' -f2`

#Misc Setting
FCG=`grep "item.1.1" /tmp/aroma/misc.prop | cut -d '=' -f2`
FSYNC=`grep "item.1.2" /tmp/aroma/misc.prop | cut -d '=' -f2`

#Start
echo "#!/sbin/busybox sh" > $SCRIPT

#Governor Setting
if [ $GOVERNOR = 1 ]; then
echo "echo interactive > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 2 ]; then
echo "echo lazy > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 3 ]; then
echo "echo dancedance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 4 ]; then
echo "echo optimax > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 5 ]; then
echo "echo intellidemand > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 6 ]; then
echo "echo uberdemand > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 7 ]; then
echo "echo ondemand > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 8 ]; then
echo "echo ondemandplus > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 9 ]; then
echo "echo intelliactive > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 10 ]; then
echo "echo HYPER > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 11 ]; then
echo "echo nightmare > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 12 ]; then
echo "echo pegasusq > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 13 ]; then
echo "echo badass > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 14 ]; then
echo "echo lionheart > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
elif [ $GOVERNOR = 15 ]; then
echo "echo abyssplugv2 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" >> $SCRIPT;
fi

#Max Freq Setting
if [ $MAXFREQ = 1 ]; then
echo "echo 2265600 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq" >> $SCRIPT;
elif [ $MAXFREQ = 2 ]; then
echo "echo 1958400 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq" >> $SCRIPT;
elif [ $MAXFREQ = 3 ]; then
echo "echo 1728000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq" >> $SCRIPT;
elif [ $MAXFREQ = 4 ]; then
echo "echo 1574400 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq" >> $SCRIPT;
fi

#Min Freq Setting
if [ $MINFREQ = 1 ]; then
echo "echo 300000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq" >> $SCRIPT;
elif [ $MINFREQ = 2 ]; then
echo "echo 422400 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq" >> $SCRIPT;
elif [ $MINFREQ = 3 ]; then
echo "echo 652800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq" >> $SCRIPT;
elif [ $MINFREQ = 4 ]; then
echo "echo 729600 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq" >> $SCRIPT;
elif [ $MINFREQ = 5 ]; then
echo "echo 883200 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq" >> $SCRIPT;
fi

#IDLEMAXFREQ
if [ $IDLEMAXFREQ = 1 ]; then
echo "echo 1190400 > /sys/devices/system/cpu/cpu0/cpufreq/screen_off_max_freq" >> $SCRIPT;
elif [ $IDLEMAXFREQ = 2 ]; then
echo "echo 1036800 > /sys/devices/system/cpu/cpu0/cpufreq/screen_off_max_freq" >> $SCRIPT;
elif [ $IDLEMAXFREQ = 3 ]; then
echo "echo 960000 > /sys/devices/system/cpu/cpu0/cpufreq/screen_off_max_freq" >> $SCRIPT;
elif [ $IDLEMAXFREQ = 4 ]; then
echo "echo 883200 > /sys/devices/system/cpu/cpu0/cpufreq/screen_off_max_freq" >> $SCRIPT;
elif [ $IDLEMAXFREQ = 5 ]; then
echo "echo 729600 > /sys/devices/system/cpu/cpu0/cpufreq/screen_off_max_freq" >> $SCRIPT;
fi

#IO Setting
if [ $IO = 1 ]; then
echo "echo sio > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
elif [ $IO = 2 ]; then
echo "echo noop > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
elif [ $IO = 3 ]; then
echo "echo deadline > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
elif [ $IO = 4 ]; then
echo "echo row > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
elif [ $IO = 5 ]; then
echo "echo cfq > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
elif [ $IO = 6 ]; then
echo "echo fiops > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
elif [ $IO = 7 ]; then
echo "echo zen > /sys/block/mmcblk0/queue/scheduler" >> $SCRIPT;
fi

#IO BufferSize
if [ $BUFFERSIZE = 1 ]; then
echo "echo 128 > /sys/block/mmcblk0/queue/read_ahead_kb" >> $SCRIPT;
elif [ $BUFFERSIZE = 2 ]; then
echo "echo 256 > /sys/block/mmcblk0/queue/read_ahead_kb" >> $SCRIPT;
elif [ $BUFFERSIZE = 3 ]; then
echo "echo 384 > /sys/block/mmcblk0/queue/read_ahead_kb" >> $SCRIPT;
elif [ $BUFFERSIZE = 4 ]; then
echo "echo 512 > /sys/block/mmcblk0/queue/read_ahead_kb" >> $SCRIPT;
fi

#DT2W
if [ $DT2W = 1 ]; then
echo "echo 1 > /sys/android_touch/doubletap2wake" >> $SCRIPT;
elif [ $DT2W = 2 ]; then
echo "echo 2 > /sys/android_touch/doubletap2wake" >> $SCRIPT;
elif [ $DT2W = 3 ]; then
echo "echo 2 > /sys/android_touch/doubletap2wake" >> $SCRIPT;
fi

#S2W
echo "echo $S2W > /sys/android_touch/sweep2wake" >> $SCRIPT;

#TimeOut for S2W, DT2W
if [ $TIMEOUT = 1 ]; then
  echo "echo 0 > /sys/android_touch/wake_timeout" >> $SCRIPT;
elif [ $TIMEOUT = 2 ]; then
  echo "echo 5 > /sys/android_touch/wake_timeout" >> $SCRIPT;
elif [ $TIMEOUT = 3 ]; then
  echo "echo 15 > /sys/android_touch/wake_timeout" >> $SCRIPT;
elif [ $TIMEOUT = 4 ]; then
  echo "echo 30 > /sys/android_touch/wake_timeout" >> $SCRIPT;
elif [ $TIMEOUT = 5 ]; then
  echo "echo 60 > /sys/android_touch/wake_timeout" >> $SCRIPT;
elif [ $TIMEOUT = 6 ]; then
  echo "echo 90 > /sys/android_touch/wake_timeout" >> $SCRIPT;
elif [ $TIMEOUT = 7 ]; then
  echo "echo 120 > /sys/android_touch/wake_timeout" >> $SCRIPT;
fi

#S2W/DT2W Power key toggle
if [ $PWR_KEY = 1 ]; then
  echo "echo 1 > /sys/module/qpnp_power_on/parameters/pwrkey_suspend" >> $SCRIPT;
else
  echo "echo 0 > /sys/module/qpnp_power_on/parameters/pwrkey_suspend" >> $SCRIPT;
fi

#Vibration strength of S2W or DT2W.

if [ $VIB_STRENGTH = 1 ]; then
  echo "echo 0 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 2 ]; then
  echo "echo 10 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 3 ]; then
  echo "echo 20 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 4 ]; then
  echo "echo 30 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 5 ]; then
  echo "echo 40 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 6 ]; then
  echo "echo 50 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 7 ]; then
  echo "echo 60 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 8 ]; then
  echo "echo 70 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 9 ]; then
  echo "echo 80 > /sys/android_touch/vib_strength" >> $SCRIPT;
elif [ $VIB_STRENGTH = 10 ]; then
  echo "echo 90 > /sys/android_touch/vib_strength" >> $SCRIPT;
fi

#S2S(Not Draining Battery!)
if [ $S2S = 1 ]; then
  echo "echo 0 > /sys/android_touch/sweep2sleep" >> $SCRIPT;
elif [ $S2S = 2 ]; then
  echo "echo 1 > /sys/android_touch/sweep2sleep1" >> $SCRIPT;
elif [ $S2S = 3 ]; then
  echo "echo 2 > /sys/android_touch/sweep2sleep" >> $SCRIPT;
elif [ $S2S = 4 ]; then
  echo "echo 3 > /sys/android_touch/sweep2sleep" >> $SCRIPT;
fi

#VIB
if [ $VIB = 1 ]; then
echo "echo 10 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 2 ]; then
echo "echo 20 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 3 ]; then
echo "echo 30 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 4 ]; then
echo "echo 40 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 5 ]; then
echo "echo 50 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 6 ]; then
echo "echo 60 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 7 ]; then
echo "echo 70 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 8 ]; then
echo "echo 80 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 9 ]; then
echo "echo 90 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
elif [ $VIB = 10 ]; then
echo "echo 100 > /sys/class/timed_output/vibrator/driving_ms" >> $SCRIPT;
fi

#MISC
if [ $FCG = 1 ]; then
echo "echo 1 > /sys/kernel/fast_charge/force_fast_charge" >> $SCRIPT;
fi

if [ $FSYNC = 1 ]; then
  echo "echo 0 > /sys/module/sync/parameters/fsync_enabled;" >> $SCRIPT;
else
  echo "echo 1 > /sys/module/sync/parameters/fsync_enabled;" >> $SCRIPT;
fi

#chmod 755 /system/etc/init.d
chmod 755 $SCRIPT
